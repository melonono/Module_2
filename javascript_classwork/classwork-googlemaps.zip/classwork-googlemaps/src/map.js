let map = new google.maps.Map(document.getElementById("map"),{
  center: {lat:55.547330, lng:13.952510},
  zoom: 15,
});

let marker = new google.maps.Marker({
  position: {lat:13.952510, lng: 13.952510},
  map: map,
  draggable: true,
});

console.log(map);